# devopslab1
this repo is for the devops lab 1 
